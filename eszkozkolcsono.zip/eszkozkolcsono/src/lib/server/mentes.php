<?php
// Adatbázis kapcsolat
$servername = "localhost";
$username = "felhasználónév";
$password = "jelszó";
$dbname = "kolcsonzesek";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}

// Adatok fogadása
$szemely = $_POST["szemely"];
$eszkoz = $_POST["eszkoz"];
$mettol = $_POST["mettol"];
$meddig = $_POST["meddig"];

// Adatok mentése
$sql = "INSERT INTO kolcsonzesek (szemely, eszkoz, mettol, meddig)
VALUES ('$szemely', '$eszkoz', '$mettol', '$meddig')";

if ($conn->query($sql) === TRUE) {
    echo "Adatok sikeresen mentve";
} else {
    echo "Hiba az adatok mentésekor: " . $conn->error;
}

$conn->close();
?>
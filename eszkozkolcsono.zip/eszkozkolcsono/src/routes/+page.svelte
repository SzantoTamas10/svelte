<script>
     // @ts-ignore
     /**
     * @type {any[]}
     */
     let kolcsonzesek = [];

let szemely = "";
let eszkoz = "";
let mettol = "";
let meddig = "";

async function kolcsonzesHozzaadasa() { // Ezt csak *egyszer* definiáld!
    if (szemely && eszkoz && mettol && meddig) {
        try {
            const response = await fetch('/mentes.php', { // Az URL-t állítsd be!
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `szemely=${szemely}&eszkoz=${eszkoz}&mettol=${mettol}&meddig=${meddig}`
            });

            const data = await response.text();
            console.log(data);

            // @ts-ignore
            kolcsonzesek = [...kolcsonzesek, { szemely, eszkoz, mettol, meddig }];
            szemely = "";
            eszkoz = "";
            mettol = "";
            meddig = "";

        } catch (error) {
            console.error('Hiba:', error);
            alert("Hiba történt a mentés során!"); // Felhasználóbarát hibaüzenet
        }
    } else {
        alert("Kérjük, töltsön ki minden mezőt!");
    }
}

// @ts-ignore
function kolcsonzesTorlese(index) {
    // @ts-ignore
    kolcsonzesek = kolcsonzesek.filter((_, i) => i !== index);
}
</script>

<h1>Eszköz Kölcsönzés</h1>

<div class="container">
    <div class="form-section">
        <form on:submit|preventDefault={kolcsonzesHozzaadasa}>
            <label for="szemely">Személy:</label><br>
            <input type="text" id="szemely" bind:value={szemely} required><br><br>

            <label for="eszkoz">Eszköz:</label><br>
            <input type="text" id="eszkoz" bind:value={eszkoz} required><br><br>

            <label for="mettol">Mettől:</label><br>
            <input type="datetime-local" id="mettol" bind:value={mettol} required><br><br>

            <label for="meddig">Meddig:</label><br>
            <input type="datetime-local" id="meddig" bind:value={meddig} required><br><br>

            <button type="submit">Hozzáadás</button>
        </form>
    </div>

    <div class="table-section">
        <h2>Kölcsönzések</h2>
        <table>
            <thead>
                <tr>
                    <th>Személy</th>
                    <th>Eszköz</th>
                    <th>Mettől</th>
                    <th>Meddig</th>
                    <th>Művelet</th>
                </tr>
            </thead>
            <tbody>
                {#each kolcsonzesek as kolcsonzes, index}
                    <tr>
                        <td>{kolcsonzes.szemely}</td>
                        <td>{kolcsonzes.eszkoz}</td>
                        <td>{kolcsonzes.mettol}</td>
                        <td>{kolcsonzes.meddig}</td>
                        <td><button on:click={() => kolcsonzesTorlese(index)}>Törlés</button></td>
                    </tr>
                {/each}
                {#if kolcsonzesek.length === 0}
                    <tr><td colspan="5">Nincsenek kölcsönzések.</td></tr>
                {/if}
            </tbody>
        </table>
    </div>
</div>

<style>
     .container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .form-section {
        /* Opcionális: Ha szeretnéd, hogy az űrlap ne töltse ki teljesen a rendelkezésre álló területet */
        width: 50%; 
    }

    .table-section {
        /* Opcionális: Ha szeretnéd, hogy a táblázat ne töltse ki teljesen a rendelkezésre álló területet */
         width: 50%; 
    }

    /* Reszponzivitás: Kisebb képernyőkön egymás alá kerüljenek */
    @media (max-width: 768px) {
        .container {
            grid-template-columns: 1fr;
        }
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    form label {
        display: block; /* Címkék külön sorban */
    }

    form input[type="text"],
    form input[type="datetime-local"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        box-sizing: border-box;
    }
</style>